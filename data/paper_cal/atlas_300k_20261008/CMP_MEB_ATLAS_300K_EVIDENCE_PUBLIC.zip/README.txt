B0-2D-PAPER-CAL 300K MEB Atlas evidence ZIP
All original CSV files remain unchanged. Source paths/hashes in metadata/source_manifest.csv.
Processed master is PROVISIONAL. Validate before scientific freeze / GitHub commit.
No SWB project .tdr/.plt data included. Preserve them on TCAD host.
